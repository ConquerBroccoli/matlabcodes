function [results,approx]=wavDec(t,x,G,mth,ox)
%% a collection of all methods for decomposing signal
%W: normalized adjacency matrix
%x: signal
%t: number of layers
%mth: method

N=length(x);
dxl=x;
results=cell(t,7);
coords=G.coords;
ncoord=coords;
ncoord(:,1)=(coords(:,1)-min(coords(:,1)))./(max(coords(:,1))-min(coords(:,1)));
ncoord(:,2)=(coords(:,2)-min(coords(:,2)))./(max(coords(:,2))-min(coords(:,2)));
nW=full(G.W);
rD=diag(sum(nW));
%normalized adjacency
W=rD^(-1/2)*nW*rD^(-1/2);
tar=ox;%<----
%% decomposition
if mth~=4
    %sampling in the vertex domain
    for i=1:t
        xl=dxl;
        %% construct filterbank
        [K,GA,~]=produce_filter(W,mth);
        %DC-zero filters
        HL=rD^(-1/2)*1/2*(eye(N)+GA)*rD^(1/2);
        HH=rD^(-1/2)*1/2*(eye(N)-GA)*rD^(1/2);
        Htotal=1/2*rD^(-1/2)*(eye(N)+K*GA)*rD^(1/2); %total transformation
        %% filtering and sampling
        xh=HH*xl;
        xl=HL*xl;


        dxl=xl(diag(K)==1);
        dxh=xh(diag(K)==-1);
        
        %compute relative error
        tar=tar(diag(K)==1);
        re=norm(dxl-tar)/norm(tar)
        %% graph reduction
        %non-normalized Laplacian for kron reduction
        nL=diag(sum(nW))-nW;
        rL=kronL(nL,K,N);
        rD=diag(diag(rL));
        nW=rD-rL;
        N=length(nW);
        W=rD^(-1/2)*nW*rD^(-1/2);
        W=(W+W')/2;
        ncoord=ncoord(diag(K)==1,:);
        iG=gsp_graph(nW);
        iG.coords=ncoord;
        %save results
        results(i,:)={dxh,K,Htotal,W,re,iG,dxl}; 
    end
else
    % Method 4: sampling in the spectral domain
    results=cell(t,8);
    [U,V]=eig(W);
    [~,vid]=sort(diag(V),'descend'); %W is the adjacency
    U=U(:,vid);
    for i=1:t
        Pre_xl_hat=U'*dxl;
        %% construct filterbank
        [~,~,respon]=produce_filter(W,mth);
        %filters and samplers
        hL=1/2*(ones(N,1)+respon);
        hH=1/2*(ones(N,1)-respon);
        J=flip(eye(N));
        HINV=U*pinv(eye(N)+J*diag(respon)); %the synthesis filter
        DownL=[eye(N/2),flip(eye(N/2))];
        DownH=[eye(N/2),-flip(eye(N/2))];

        %% filtering and sampling
        xh_hat=hH.*Pre_xl_hat;
        xl_hat=hL.*Pre_xl_hat;
        
        
        %downsampling in the spectral domain
        dxl_hat=DownL*xl_hat;
        dxh_hat=DownH*xh_hat;

        %% graph reduction
        %non-normalized Laplacian for kron reduction
        kvec=ones(N,1);kvec(1:2:N)=-1;
        %sampling at one another
        K=diag(kvec);
        nL=diag(sum(nW))-nW;
        rL=kronL(nL,K,N);
        rD=diag(diag(rL));
        nW=rD-rL;
        N=length(nW);
        W=rD^(-1/2)*nW*rD^(-1/2);
        W(W<=1e-5)=0;
        W=(W+W')/2;
        [U,V]=eig(W);
        [~,vid]=sort(diag(V),'desc'); %W is the adjacency
        U=U(:,vid);
        dxl=U*dxl_hat; %a shorter signal on the reduced graph
        
        %compute relative error
        tar=tar(diag(K)==1);
        re=norm(dxl-tar)/norm(tar);
        
        
        %edge sparsification
        %Q=round(16*N*log(N));
        %W=sparsify(N,rW,Q,rL);
        ncoord=ncoord(diag(K)==1,:);
        iG=gsp_graph(nW);
        iG.coords=ncoord;

        %save results
        results(i,:)={dxh_hat,K,HINV,W,U,re,iG,dxl}; 
    end
    
end
approx=dxl;
end