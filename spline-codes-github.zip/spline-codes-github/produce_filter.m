function [K,GA,response]=produce_filter(W,mth)
%% produce the spline-like filters using different methods
%W: the normalized adjacency
%mth:1: proposed method; 2:literOpt 3:MSGFB 4:SGFBSS


%% basic information
N=length(W);
W=(W+W')/2;
[U,v]=eig(W);
diagv=diag(v);
[diagv,sid]=sort(diagv,'descend');
U=U(:,sid);

J=5;
Gamma=zeros(N,J);
for i=1:J
    Gamma(:,i)=diagv.^(i-1);
end

%% 
tol=1e-5;
h_ideal=zeros(N,1);
h_ideal(diagv>median(diagv))=1;%linspace(0,1,floor(N/2)); %desired ideal filter
h_des=h_ideal;
r=1; s=4; 
K=ProposedSampling(r,s,U);
switch mth
    case 1
        %the proposed method
        alpha=0.01; %for regular term
        regular_term=[zeros(N,1),Gamma(:,1:J-1)]*diag(0:(J-1));
        %K=ProposedSampling(r,s,U);
        if ~isempty(K)
            % the sampling pattern exists
            % get all distinct engenvalues
            uniq_v=sort(uniquetol(diagv,1e-4),'descend');
            Gr=zeros(r,J);
            Gs=zeros(s,J);
            Gc=zeros(length(uniq_v)-r-s,J);
            for j=1:J
                Gr(:,j)=uniq_v(1:r).^(j-1);
                Gs(:,j)=uniq_v(length(uniq_v)-s+1:end).^(j-1);
                Gc(:,j)=uniq_v(r+1:length(uniq_v)-s).^(j-1);
            end
            n=length(uniq_v);
            
            cvx_begin
                variable w(J)
                minimize(norm(h_des-1/2*(1+Gamma*w),inf)+alpha*norm(regular_term*w,2))
                subject to
                [Gr;Gs]*w==[ones(r,1);-ones(s,1)] %Gr*w == ones(r,1) && Gs*w == -ones(s,1);
                Gc*w<=1-tol
                Gc*w>=-1+tol
            cvx_end
        else
            disp('The sampling pattern does not exist.')
        end  
    case 2
        %literOpt
        cvx_begin
            variable w(J)
            minimize(norm(h_des-1/2*(1+Gamma*w),inf))
            subject to
            w'*ones(size(w))==1
            w>=tol
        cvx_end
    case 3
        %MSGFB
        cvx_begin
            variable w(J)
            minimize(norm(h_des-1/2*(1+Gamma*w),inf))
            subject to
            Gamma*w>=-1+tol
            Gamma*w<=1-tol
        cvx_end
    case 4
        %SGFBSS
        cvx_begin
            variable w(J)
            minimize(norm(h_des-1/2*(1+Gamma*w),inf))
            subject to
            Gamma*w>=-1+tol
            Gamma*w<=1-tol
        cvx_end
    otherwise
        disp('Select a method.')
end

response=Gamma*w;
GA=U*diag(response)*U';

end