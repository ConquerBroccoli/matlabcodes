function reconx=reconstruction(results,approx,mth,thres)
%thres: threshold

%% reconstruction
t=size(results,1); %number of layers
if mth~=4
    for i=1:t
        dxl=approx;
        tmp=results(t-i+1,:);
        dxh=tmp{1};
        %hard threshold
        dxh(dxh<=thres)=0;
        K=tmp{2};
        Htotal=tmp{3};
        %upsampling
        xl=zeros(length(K),1);
        xh=zeros(length(K),1);
        xl(diag(K)==1)=dxl;
        xh(diag(K)==-1)=dxh;

        %reconstruction filtering
        y=xl+xh; 
        approx=Htotal\y;
    end
else
    %Method 4
    for i=1:t
        dxl=approx; %in the vertex domain
        tmp=results(t-i+1,:);
        dxh_hat=tmp{1};
        HINV=tmp{3};
        U=tmp{5};
        %upsampling
        dxl_hat=U'*dxl; %transformed into spectral domain
        N=length(U);
        %hard threshold
        dxh=U*dxh_hat;
        dxh(dxh<=thres)=0;
        dxh_hat=U'*dxh;
        xl_hat=[eye(N);flip(eye(N))]*dxl_hat;
        xh_hat=[eye(N);-flip(eye(N))]*dxh_hat;
        
        y_hat=xl_hat+xh_hat;

        %filtering
        approx=HINV*y_hat;
    end
end
reconx=approx;
end