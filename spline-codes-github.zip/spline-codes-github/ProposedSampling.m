function K=ProposedSampling(r,s,U)
N=length(U);
Ur=U(:,1:r);
Us=U(:,N+1-s:N);
%% produce A B
%find a full rank s ubmatrix Urr and a full rank Uss
eps=1e-2;
restids=1:N;
tmpUr=Ur(restids,:);

[~,rids]=rref(tmpUr',eps); %Ur'(:,rids) is a basis for the range of Ur'
rids=restids(rids);

restids(ismember(restids,rids))=[];
tmpUs=Us(restids,:);
if rank(tmpUs)<s
    %T is not full row rank
    K=[];
    sprinft('the rest submatrix of Us is not full rank')
else
    [~,sids]=rref(tmpUs',eps);
    sids=restids(sids);
    %restids(ismember(restids,sids))=[];
    uN=U(:,N);
    % use the polarity to partition A B and design a sampling pattern K
    K=ones(N,1);
    K(uN<0)=-1;K(sids)=-1;
    K=diag(K);
end
end